export type Lang = "en" | "fa";

export type Messages = Record<string, string>;
